import pygame
import random

# Inițializare pygame
pygame.init()
pygame.mixer.init()

# Setări ecran
WIDTH, HEIGHT = 640, 480
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Joc PyGame")
clock = pygame.time.Clock()

# Scor, vieți, nivel
score = 0
lives = 3
level = 1
victory = False
running = True

# Fundal
background = pygame.image.load('images/bg.png')
background = pygame.transform.scale(background, (640, 480))

# În bucla principală:
screen.blit(background, (0, 0))

# Sunete
hit_sound = pygame.mixer.Sound('sounds/hit.wav')
win_sound = pygame.mixer.Sound('sounds/win.wav')
fail_sound = pygame.mixer.Sound('sounds/fail.wav')
laser_sound = pygame.mixer.Sound('sounds/laser.wav')  

# Jucator
player_frames = [
    pygame.image.load('images/ship1.png'),
    pygame.image.load('images/ship2.png')
]
player_current_frame = 0
player_image = player_frames[player_current_frame]
player_rect = player_image.get_rect(center=(WIDTH//2, HEIGHT-60))
player_speed = 5

# Inamici si lasere
enemies = []
laser_image = pygame.image.load('images/laser.png')  # Adauga imaginea laserului
laser_rects = []
last_shot_time = 0
laser_cooldown = 2000  # 2 secunde in milisecunde

# Ecran start
font = pygame.font.SysFont(None, 48)
screen.blit(background, (0, 0))
text = font.render("APASA O TASTA PENTRU A PORNI", True, (255,255,255))
screen.blit(text, (60, HEIGHT//2))
pygame.display.flip()
waiting = True
while waiting:
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            waiting = False

# Jocul efectiv
while running:
    delta_time = clock.tick(60) / 1000                            #   mod
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Input miscare
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player_rect.x -= player_speed
    if keys[pygame.K_RIGHT]:
        player_rect.x += player_speed

    # Tragere laser
    if keys[pygame.K_SPACE]:
        current_time = pygame.time.get_ticks()
        if current_time - last_shot_time >= laser_cooldown:
            laser_rect = laser_image.get_rect(midbottom=player_rect.midtop)
            laser_rects.append(laser_rect)
            laser_sound.play()
            last_shot_time = current_time

    # Animatie jucator
    player_current_frame = (player_current_frame + 1) % len(player_frames)
    player_image = player_frames[player_current_frame]

    # Generare inamici
    #if random.randint(1, int((clock.get_fps()  ))) == 1:   #
    if random.uniform(0,1) <= delta_time:
        try:
            enemy_image = pygame.image.load('images/enemy1.png')
        except:
            enemy_image = pygame.Surface((40, 40))
            enemy_image.fill((255, 0, 0))
        enemy_rect = enemy_image.get_rect()
        enemy_rect.x = random.randint(0, WIDTH - 40)
        enemy_rect.y = -40
        enemy_speed = 3 + level
        enemies.append({'image': enemy_image, 'rect': enemy_rect, 'speed': enemy_speed})

    # Update inamici
    for enemy in enemies[:]:
        enemy['rect'].y += enemy['speed']                         #mod
        if enemy['rect'].top > HEIGHT:
            enemies.remove(enemy)

    # Miscare lasere
    for laser in laser_rects[:]:
        laser.y -= 10
        if laser.bottom < 0:
            laser_rects.remove(laser)

    # Coliziune laser-inamic
    for laser in laser_rects[:]:
        for enemy in enemies[:]:
            if laser.colliderect(enemy['rect']):
                hit_sound.play()
                enemies.remove(enemy)
                if laser in laser_rects:
                    laser_rects.remove(laser)
                break

    # Coliziuni jucator-inamici
    for enemy in enemies[:]:
        if player_rect.colliderect(enemy['rect']):
            hit_sound.play()
            enemies.remove(enemy)
            lives -= 1
            if lives <= 0:
                victory = False
                fail_sound.play()
                running = False

    # Scor si dificultate
    score += 1
    if score >= 2500:
        victory = True
        win_sound.play()
        running = False
    if score > 1000 and level == 1:
        level = 2
    if score > 1700 and level == 2:
        level = 3

    # Desenare pe ecran
    screen.blit(background, (0, 0))
    screen.blit(player_image, player_rect)
    for enemy in enemies:
        screen.blit(enemy['image'], enemy['rect'])
    for laser in laser_rects:
        screen.blit(laser_image, laser)

    font_small = pygame.font.SysFont(None, 36)
    screen.blit(font_small.render(f"Scor: {score}", True, (255,255,255)), (10, 10))
    screen.blit(font_small.render(f"Vieti: {lives}", True, (255,255,255)), (10, 40))
    screen.blit(font_small.render(f"Nivel: {level}", True, (255,255,255)), (10, 70))
    pygame.display.flip()

# Ecran final
screen.blit(background, (0, 0))
if victory:
    text = font.render("FELICITARI, AI CASTIGAT!", True, (0,255,0))
else:
    text = font.render("GAME OVER!", True, (255,0,0))
screen.blit(text, (80, HEIGHT//2))
pygame.display.flip()
pygame.time.wait(3000)
pygame.quit()
